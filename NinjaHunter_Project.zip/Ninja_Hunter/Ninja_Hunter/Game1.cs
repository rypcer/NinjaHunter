﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using Ninja_Hunter.CustomLibrary;
using Ninja_Hunter.Sprites;
using Microsoft.Xna.Framework.Media;
namespace Ninja_Hunter
{

    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        
        #region Properties
        private Camera camera;
        private List<Sprite> _animations;
        private List<Sprite> _sprites;
        Texture2D Background;
        Texture2D Background2;
        Texture2D deathscreen;
        Texture2D instructions;
        Texture2D introscreen;
        Player p1;
        bool deathscreenOn = false;
        bool introscreenOn = true;
        bool instructionsOn = false;
        bool fadein= true;
        bool fadeout = false;
        bool delay = false;
        bool blackfade = false;
        float elapsedtime;
        float duration = 200f;
        float counter = 0f ; 
        //float duration = 200f;
        float alpha = 0f;
        public static int ScreenHeight;
        public static int ScreenWidth;
        //Chatbox
        ChatBox chatbox;
        
        #endregion



        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }


        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            
            ScreenWidth = graphics.PreferredBackBufferHeight;
            ScreenHeight = graphics.PreferredBackBufferWidth;

            
            graphics.ApplyChanges();
            
            base.Initialize();
        }


        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            camera = new Camera();
            Song backgroundMusic = Content.Load<Song>("Sounds/bgmusic");

            MediaPlayer.IsRepeating = true;
            MediaPlayer.Play(backgroundMusic);
            MediaPlayer.Volume = 0.1f;

            Background = Content.Load<Texture2D>("Background_Level1");
            Background2 = Content.Load<Texture2D>("Background_Level11");
            deathscreen = Content.Load<Texture2D>("deathscreen");
            introscreen = Content.Load<Texture2D>("intro");
            instructions = Content.Load<Texture2D>("intructions");
            var chatfont = Content.Load<SpriteFont>("Fonts/chatfont");
            var playerMoves = Content.Load<Texture2D>("Animations/ninja_movement");
            var playerAttack = Content.Load<Texture2D>("Animations/ninja_attack");
            var masteridle = Content.Load<Texture2D>("Animations/master_idle");
            var marco_idle = Content.Load<Texture2D>("Animations/marco_idle");
            var scroll = Content.Load<Texture2D>("Animations/scroll-animation");
            var boxfill = Content.Load<Texture2D>("whitepixel");
            var shurikenT = Content.Load<Texture2D>("shurikenTexture");
            var chatboxmaster = Content.Load<Texture2D>("masterchatbox");
            var woodbox = Content.Load<Texture2D>("woodbox");
            var metalbar = Content.Load<Texture2D>("metalbar");
            var metalspike = Content.Load<Texture2D>("metalspike");

            var roof = Content.Load<Texture2D>("roof");
            var pole = Content.Load<Texture2D>("Spear");
            var pole2 = Content.Load<Texture2D>("Spear2");
            var spikes = Content.Load<Texture2D>("spikes");
            var label_mag = Content.Load<Texture2D>("label_mag");
            var liljay = Content.Load<Texture2D>("liljay");


            _animations = new List<Sprite>() {
                new Animated(masteridle){
                    Height = masteridle.Height,
                    Width = masteridle.Width/2,
                    frames_end = 1,
                    collisionOn = false,
                    Position = new Vector2(368,320)
                },
                new Animated(marco_idle){
                    Height = marco_idle.Height,
                    Width = marco_idle.Width/2,
                    frames_end = 1,
                    collisionOn = false,
                    Position = new Vector2(4508,205)
                },
                new Animated(scroll){
                    Height = scroll.Height,
                    Width = scroll.Width/6,
                    frames_end = 5,
                    collisionOn = false,
                    Position = new Vector2(120,90)
                },
            };
            _sprites = new List<Sprite>()
              {
                new Player(playerMoves,playerAttack,boxfill,shurikenT)
                {
                  Input = new Input()
                  {
                    Left = Keys.A,
                    Right = Keys.D,
                    Up = Keys.W,
                    Down = Keys.S,
                    Attack = Keys.Space,
                    Attack2 = Keys.LeftShift,
                  },
                  T_Height = 128,
                  T_Width = 88,
                  Height = 128,
                  Width = 88,
                  A_Height = 128,
                  A_Width = 150,
                  Position = new Vector2(100, 300), //100 pos X
                  TPosition = new Vector2(100, 300),
                  Colour = Color.White,
                  Speed = 6,
                  gravity_on = true,
                  Velocity = new Vector2(0,0)

                },


                //Floor
                new CollisionBox(boxfill){
                    Height = 30,
                    Width = 4730,
                    Position = new Vector2(0,455)

                },
                // Lil Jay
                  new EnemyPerson(liljay){
                    Height = liljay.Height,
                    Width = liljay.Width,
                    DistanceL = 100,
                    DistanceR = 100,
                    Speed = 5,
                    Health = 50,
                    gravity_on = true,
                    MoveL=true,
                    Position = new Vector2(4000,300),
                },
               
                 //Wall left
                new CollisionBox(boxfill){
                    Height = 800,
                    Width = 5,
                    Position = new Vector2(-5,0),

                },
                // Wall Right
                new CollisionBox(boxfill){
                    Height = 800,
                    Width = 5,
                    Position = new Vector2(4720,0),

                },
                //Gate Collsion
                new CollisionBox(boxfill){
                    Height = 260,
                    Width = 153,
                    Position = new Vector2(1547,195),

                },
                new CollisionBox(boxfill){
                    Height = 40,
                    Width = 430,
                    Position = new Vector2(1400,130),

                },
                
                 // Moveable Wooden Box
                new Sprite(woodbox){
                    Height = 67,
                    Width = 54,
                    gravity_on = true,
                    Position = new Vector2(637,170),
                    moveable = true
                },
                // Metalbar
                new Sprite(metalbar){
                    Height = 12,
                    Width = 201,
                    Health = 1,
                    destroyable = true,
                    Position = new Vector2(530,250),

                },
                //Dojo Collision
                 new CollisionBox(boxfill){
                    Height = 30,
                    Width = 300,
                    Position = new Vector2(855,250),

                },

                 new CollisionBox(boxfill){
                    Height = 320,
                    Width = 55,
                    Position = new Vector2(800,0),

                },
                  new CollisionBox(boxfill){
                    Height = 170,
                    Width = 105,
                    Position = new Vector2(855,0),

                },
                
                //Collect label ma G
                 new Collectable(label_mag){
                    Height = label_mag.Height,
                    Width = label_mag.Width,
                    
                    Position = new Vector2(4510,62),

                },
                 //Boss Room
                   new CollisionBox(boxfill){
                    Height = 30,
                    Width = 380,
                    Position = new Vector2(3260,250),

                },
                       new CollisionBox(boxfill){
                    Height = 310,
                    Width = 65,
                    Position = new Vector2(3560,0),

                },
                    //Stairs
                    new CollisionBox(boxfill){
                    Height = 50,
                    Width = 250,
                    Position = new Vector2(4360,400),

                },
                      //Stairs
                    new CollisionBox(boxfill){
                    Height = 50,
                    Width = 250,
                    Position = new Vector2(4480,350),

                },

                    new Enemy(metalspike){
                    Height = label_mag.Height,
                    Width = label_mag.Width,
                    DistanceL = 50,
                    DistanceR = 50,
                    Speed = 5,
                    //gravity_on = true,
                    
                    MoveL=true,
                    Position = new Vector2(2350,360),
                },
                    new Enemy(metalspike){
                    Height = label_mag.Height,
                    Width = label_mag.Width,
                    DistanceL = 50,
                    DistanceR = 50,
                    Speed = 7,
                    //gravity_on = true,
                    
                    MoveR=true,
                    Position = new Vector2(2550,360),
                },
                    //Spikes
                    new Enemy(spikes){
                    Height = spikes.Height-10,
                    Width = spikes.Width,
                    Speed = 1,
                    DistanceU = 1,
                    DistanceD = 1,
                    Damage = 1,
                    MoveD = true,
                    Bounceback = 12,
                    Position = new Vector2(2300,433),
                },
                    new Enemy(pole2){
                    Height = pole2.Height,
                    Width = pole2.Width,
                    DistanceU = 50,
                    DistanceD = 50,
                    Speed = 100,
                    //gravity_on = true,
                    Bounceback = 2,
                    MoveU=true,
                    Position = new Vector2(2420,330),
                },
                
                  new Enemy(spikes){
                    Height = spikes.Height-10,
                    Width = spikes.Width,
                    Speed = 1,
                    DistanceU = 1,
                    DistanceD = 1,
                    Damage = 1,
                    MoveD = true,
                    Bounceback = 12,
                    Position = new Vector2(2520,433),
                },
               
                 
                     new Enemy(pole){
                    Height = pole.Height,
                    Width = pole.Width,
                    DistanceU = 50,
                    DistanceD = 50,
                    Speed = 10,
                    //gravity_on = true,
                    
                    MoveU=true,
                    Position = new Vector2(2880,50),
                },
                     new Enemy(pole){
                    Height = pole.Height,
                    Width = pole.Width,
                    DistanceU = 50,
                    DistanceD = 50,
                    Speed = 10,
                    //gravity_on = true,
                    
                    MoveD=true,
                    Position = new Vector2(2180,50),
                },
                     // Middle - Roof
                  new Sprite(roof){
                    Height = roof.Height,
                    Width = roof.Width,
                    collisionOn = false,
                    Position = new Vector2(2050,0),

                },




              };

         
            chatbox = new ChatBox(chatboxmaster, chatfont);

            System.Console.WriteLine(graphics.PreferredBackBufferHeight);
        }


        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();


            if(Keyboard.GetState().IsKeyDown(Keys.Enter))
                graphics.ToggleFullScreen();
            // Used for SplashScreens
            if (introscreenOn)
            {
                elapsedtime += (float)gameTime.ElapsedGameTime.TotalSeconds;
                if (elapsedtime < duration && fadein)
                {
                    alpha += 0.01f;
                    if (alpha >= 1)
                    {
                        fadein = false;
                        elapsedtime = 0;
                        delay = true;
                    }

                }
                else if (counter < 300 && delay )
                {

                    counter+=elapsedtime;
                    if (counter > 300) {
                        fadeout = true;
                        delay = false;
                        elapsedtime = 0;
                    }
                    
                   
                }
                
                else if (elapsedtime < duration && fadeout)
                {
                    alpha -= 0.01f;
                    if (alpha <= 0)
                    {
                        fadeout = false;
                        elapsedtime = 0;
                    }

                }
                else if (!fadein && !fadeout) {
                    elapsedtime = 0;
                    alpha = 0;
                    counter = 0;
                    introscreenOn = false;
                    instructionsOn = true;
                    fadein = true;

                }
            }
            if (instructionsOn)
            {
                elapsedtime += (float)gameTime.ElapsedGameTime.TotalSeconds;
                if (elapsedtime < duration && fadein)
                {
                    alpha += 0.01f;
                    if (alpha >= 1)
                    {
                        fadein = false;
                        elapsedtime = 0;
                        delay = true;
                    }

                }
                else if (counter < 250 && delay)
                {

                    counter += elapsedtime;
                    if (counter > 250)
                    {
                        fadeout = true;
                        delay = false;
                        elapsedtime = 0;
                    }


                }

                else if (elapsedtime < duration && fadeout)
                {
                    alpha -= 0.01f;
                    if (alpha <= 0)
                    {
                        fadeout = false;
                        elapsedtime = 0;
                    }

                }
                else if (!fadein && !fadeout)
                {
                    elapsedtime = 0;
                    alpha = 1;
                    instructionsOn = false;
                    blackfade = true;
                }
            }
            if (blackfade) {
                elapsedtime += (float)gameTime.ElapsedGameTime.TotalSeconds;
                if (elapsedtime < duration )
                {
                    alpha -= 0.01f;
                    if (alpha <= 0)
                    {
                        blackfade = false;
                        chatbox.chatboxshow = true;
                        chatbox.dialogue_enabled = true;
                        //Extract PLayer from Sprites and assign to this class temp Player
                        if (_sprites[0] is Player)
                        {
                            p1 = _sprites[0] as Player;
                        }
                        p1.MoveLock = false;
                        elapsedtime = 0;
                        
                    }

                }

            }


            // TODO: Add your update logic here
            foreach (var sprite in _animations)
                sprite.Update(gameTime, _sprites);
            foreach (var sprite in _sprites) 
                sprite.Update(gameTime, _sprites);

            camera.Follow(_sprites[0]);
            // Check for Death
            for (int i = 0; i < _sprites.Count; i++) {
                var sprite = _sprites[i];

                if (sprite.Died)
                {
                    if (_sprites[0].Died) { deathscreenOn = true; }
                    _sprites.RemoveAt(i);
                    i--;
                }
                if (sprite is Player)
                {

                    var player = sprite as Player;

                }
            }

            chatbox.Update(_sprites,gameTime,camera,_animations);  



             base.Update(gameTime);
        }


        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            //For Ingame elements that move
            spriteBatch.Begin(transformMatrix: camera.Transform);
            spriteBatch.Draw(Background, new Vector2(0, 0), Color.White);
            spriteBatch.Draw(Background2, new Vector2(2357, 0), Color.White);
            foreach (var sprite in _animations)
                sprite.Draw(spriteBatch);
            foreach (var sprite in _sprites)
                sprite.Draw(spriteBatch);
            spriteBatch.End();

            //For UI, dialogue box or healthbars
            spriteBatch.Begin();
            chatbox.Draw(spriteBatch);
            if (deathscreenOn) { spriteBatch.Draw(deathscreen, new Vector2(0, 0), Color.White); }
            if (blackfade) { spriteBatch.Draw(introscreen, new Vector2(0, 0), Color.Black * alpha); }
            if (!introscreenOn && !instructionsOn) {  } else { spriteBatch.Draw(introscreen, new Vector2(0, 0), Color.Black); }
            if (introscreenOn) { spriteBatch.Draw(introscreen, new Vector2(0, 0), Color.White * alpha); }
            if (instructionsOn) { spriteBatch.Draw(instructions, new Vector2(0, 0), Color.White * alpha); }
            spriteBatch.End();


            base.Draw(gameTime);
        }


       

    }
}

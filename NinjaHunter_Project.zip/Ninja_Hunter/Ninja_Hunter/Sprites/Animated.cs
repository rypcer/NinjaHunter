﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Ninja_Hunter.Sprites
{
    class Animated : Sprite
    {
        //public Texture2D animation;
        float time_elapsed;
        float animation_length = 200f;  // Speed of animation frame
        bool playonce = false;
        bool stopanimation = false;
        int frames = 0;
        int state = 0;
        public int frames_start, frames_end = 0;
        public Rectangle image;
        public Animated(Texture2D texture):base(texture) {
            
        }
        public override void Update(GameTime gameTime, List<Sprite> sprites)
        {
            

            void animation(int frames_start, int frames_end)
            {

                time_elapsed += (float)gameTime.ElapsedGameTime.TotalMilliseconds;

                image = new Rectangle((frames * Width), (state * Height), Width, Height); //Change the sprite location foreach frame

                if (time_elapsed >= animation_length)
                {

                    if (frames >= frames_end)
                    {

                        if (playonce)
                        {
                            stopanimation = true;
                            playonce = false;
                        }
                        frames = frames_start;
                    }
                    else { frames++; }
                    time_elapsed = 0; //Reset to 0 
                }

                
            }
            if (!stopanimation)
                //Play animation
                animation(frames_start, frames_end);
        }
        public override void Draw(SpriteBatch spriteBatch) {
            spriteBatch.Draw(texture, Position, image, Color.White); 
        }



    }
}

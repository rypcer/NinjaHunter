﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Ninja_Hunter.CustomLibrary;


namespace Ninja_Hunter.Sprites
{
   
    public class Sprite
    {
        
        protected Texture2D texture;
      
        public int Width;
        public int Height;
        public int T_Width;
        public int T_Height;
        public int A_Width;
        public int A_Height;
        public Vector2 TPosition;
        public Vector2 APosition;
        public Vector2 SPosition;
        public Vector2 Position;
        public Vector2 Velocity;
        public Color Colour = Color.White;
        public float Speed;
        public Input Input;

        public bool gravity_on;
        float gravity_force = 15f;
        public bool moveable = false;
        public bool destroyable = false;
        public bool collisionOn = true;
        // Player Stats
        public int Health = 100;
        public bool Died = false;
        public int Damage = 5;
        public bool direction = false;

        public Rectangle HitBox
        {
            get
            {
                if (collisionOn)
                {
                    return new Rectangle((int)Position.X, (int)Position.Y, Width, Height);
                }
                else
                    return new Rectangle(0, 0,0,0);
            }
            
        }
        public Rectangle AttackBox
        {
            get
            {
                return new Rectangle((int)APosition.X, (int)APosition.Y, A_Width, A_Height);
            }
        }

        public Rectangle ShurikenBox
        {
            get
            {
                return new Rectangle((int)SPosition.X, (int)SPosition.Y,20, 20);
            }
        }

        public Sprite(Texture2D _texture)
        {
            texture = _texture;
            
        }

        public virtual void Update(GameTime gameTime, List<Sprite> sprites)
        {
            if (destroyable)
            {
                if (Health <= 0) Died = true;
            }
            if (moveable)
            {
                Gravity(gameTime);
                if (collisionOn)
                {
                    CollisionCheck(gameTime, sprites);
                }
                Position += Velocity;
                Velocity.X = 0;
            }
            
        }

        public virtual void Draw(SpriteBatch spriteBatch)
        {
            
            spriteBatch.Draw(texture, Position, Colour);
            
        }

        public virtual void Gravity(GameTime gameTime) {
            if (gravity_on == true) {
                Velocity.Y += gravity_force * (float)gameTime.ElapsedGameTime.TotalSeconds * 2;

            }
                

        }



        public virtual void CollisionCheck(GameTime gameTime, List<Sprite> sprites)
        {
            foreach (var sprite in sprites)
            {
                if (sprite == this)
                    continue;

               

                if ((this.IsTouchingLeft(sprite)) ||
                    (this.IsTouchingRight(sprite)))
                {
                    this.Velocity.X = 0;
                }



                if ((this.IsTouchingTop(sprite)) ||
                    (this.IsTouchingBottom(sprite)))
                {
                    this.Velocity.Y = 0;
                    //InAir = false;
                    //Grounded = true;
                }
                
            }
        }

        #region Collision
        protected bool IsTouchingLeft(Sprite sprite)
        {
            return this.HitBox.Right + this.Velocity.X > sprite.HitBox.Left &&
              this.HitBox.Left < sprite.HitBox.Left &&
              this.HitBox.Bottom > sprite.HitBox.Top &&
              this.HitBox.Top < sprite.HitBox.Bottom;
        }

        protected bool IsTouchingRight(Sprite sprite)
        {
            return this.HitBox.Left + this.Velocity.X < sprite.HitBox.Right &&
              this.HitBox.Right > sprite.HitBox.Right &&
              this.HitBox.Bottom > sprite.HitBox.Top &&
              this.HitBox.Top < sprite.HitBox.Bottom;
        }

        protected bool IsTouchingTop(Sprite sprite)
        {
            return this.HitBox.Bottom + this.Velocity.Y > sprite.HitBox.Top &&
              this.HitBox.Top < sprite.HitBox.Top &&
              this.HitBox.Right > sprite.HitBox.Left &&
              this.HitBox.Left < sprite.HitBox.Right;
        }

       

        protected bool IsTouchingBottom(Sprite sprite)
        {
            return this.HitBox.Top + this.Velocity.Y < sprite.HitBox.Bottom &&
              this.HitBox.Bottom > sprite.HitBox.Bottom &&
              this.HitBox.Right > sprite.HitBox.Left &&
              this.HitBox.Left < sprite.HitBox.Right;
        }

        protected bool IsOverlappedRight(Sprite sprite)
        {
            return this.AttackBox.Right > sprite.HitBox.Left &&
              this.AttackBox.Left < sprite.HitBox.Left &&
              this.AttackBox.Bottom > sprite.HitBox.Top &&
              this.AttackBox.Top < sprite.HitBox.Bottom;
        }
        protected bool IsOverlappedLeft(Sprite sprite)
        {
            return this.AttackBox.Left < sprite.HitBox.Right &&
              this.AttackBox.Right > sprite.HitBox.Right &&
              this.AttackBox.Bottom > sprite.HitBox.Top &&
              this.AttackBox.Top < sprite.HitBox.Bottom;
        }
        protected bool IsOverlappedRight2(Sprite sprite) // I could have created a temp rect variable which takes attackbox or shuriken box attributes, whenever they are called but I didnt have time 
        {
            return this.ShurikenBox.Right > sprite.HitBox.Left &&
              this.ShurikenBox.Left < sprite.HitBox.Left &&
              this.ShurikenBox.Bottom > sprite.HitBox.Top &&
              this.ShurikenBox.Top < sprite.HitBox.Bottom;
        }
        protected bool IsOverlappedLeft2(Sprite sprite)
        {
            return this.ShurikenBox.Left < sprite.HitBox.Right &&
              this.ShurikenBox.Right > sprite.HitBox.Right &&
              this.ShurikenBox.Bottom > sprite.HitBox.Top &&
              this.ShurikenBox.Top < sprite.HitBox.Bottom;
        }
        #endregion
    }
}

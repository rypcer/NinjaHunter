﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Ninja_Hunter.Sprites
{
    class Player:Sprite
    {

    #region Attributes

        //Gravity
        bool InAir = false;
        bool Grounded = true;
        public new bool direction = false;
        bool jumpkeydown = true;
        bool poslock = false;
        float JumpStrength = -12f;

        //Animation
        
        public double time_elapsed = 0;          // tracks elapsed time
        public float animation_length = 200f;  // Speed of animation frame
        public bool playonce = false;
        public int frames = 0;
        public int state = 0;


        // Attack animation
        public bool AnimState = false;
        bool AnimState2 = false;
        public bool AttackState = false;
       
        public bool attackkeydown = true;
        bool attackkeydown2 = true;
        bool shurikenshow = false;
        bool indirection = false;
        bool SThrown = false;
        float atelapsed ;
        float atduration= 0.5f;
        
        //Textures
        public Rectangle image;
        public Rectangle image2;
        public Rectangle image3;
        protected Texture2D boxfill;
        protected Texture2D shurikenT;
        protected Texture2D attackanim;
        public int T_Height2 = 128;
        public int T_Width2 = 176;
        //public bool displaydeath = false;
        //Movement
        public KeyboardState ks;
        public bool MoveLock = true;

        #endregion

        public Player(Texture2D _texture, Texture2D _texture2, Texture2D _boxfill, Texture2D _shurikenT) : base(_texture)
        {
            boxfill = _boxfill;
            attackanim = _texture2;
            shurikenT = _shurikenT;
        }

        public override void Update(GameTime gameTime, List<Sprite> sprites)
        {

            if (Health <= 0) { Died = true; }
            
            Move(gameTime);
            Gravity(gameTime);
            CollisionCheck(gameTime, sprites);
            Position+= Velocity;
            if (!AttackState && !direction) { APosition = Position; } else { APosition += Velocity; } // Attack box follows hitbox position
            if (!shurikenshow) { SPosition = Position; } 
            // Used for crouching so texture doesnt move collision box
            if (!poslock)
            {
                TPosition += Velocity;
            }
            
            Velocity.X = 0;

            

        }
        public override void Draw(SpriteBatch spriteBatch)
        {

            
            
            //spriteBatch.Draw(boxfill, Position, HitBox , Color.MediumPurple * 0.5f); //Display Collision Box
            if (AnimState == true)
            {
                //spriteBatch.Draw(boxfill, APosition, AttackBox, Color.Red * 0.5f); //Display Attack Box
                spriteBatch.Draw(attackanim, TPosition, image2, Color.White); //Display sprite animations
            }
            else if (AnimState2 == true)
            {
                
                spriteBatch.Draw(attackanim, TPosition, image2, Color.White); //Display sthrow animation
            }
            
            else
            {
                spriteBatch.Draw(texture, TPosition, image, Color.White); //Display sprite animations
            }
            if (shurikenshow == true)
            {
                //spriteBatch.Draw(boxfill, SPosition, ShurikenBox, Color.Blue * 0.5f); //Display Attack Box
                spriteBatch.Draw(shurikenT, SPosition, image3, Color.White); //Display Shuriken Texture
            }




        }


    #region Methods
        private void Move(GameTime gameTime)
        {

            // Keyboard Input
            ks = Keyboard.GetState();



            // Attack
            if (ks.IsKeyDown(Input.Attack) && !attackkeydown && !AnimState && !AnimState2 && !MoveLock) {
                AttackState = true;
                attackkeydown = true;
                AnimState = true;
                if (direction) {
                    APosition = Position;
                    APosition.X -= (A_Width - T_Width);
                }
               
            }
            // Attack2
            else if (ks.IsKeyDown(Input.Attack2) && !attackkeydown2 && !AnimState && !AnimState2 && !MoveLock)
            {
                
                attackkeydown2 = true;
                AnimState2 = true;
                shurikenshow = true;
                

            }
            //Down
            else if (ks.IsKeyDown(Input.Down) && InAir == false && Grounded == true && !AnimState && !AnimState2 && !MoveLock)
            {

                Height = 90;
                Velocity.Y = 10;
                poslock = true;
                direction_check(4, 0, 1);

            }

            // Jump 
            else if (ks.IsKeyDown(Input.Up) && InAir == false && !jumpkeydown && !AnimState && !AnimState2 && !MoveLock)
            {

                Velocity.Y = JumpStrength;
                InAir = true;
                jumpkeydown = true;
                direction_check(6, 0, 3);
            }

            //Left & Right Walk
            else if (ks.IsKeyDown(Input.Right) && !AnimState && !AnimState2 && !MoveLock)
            {
                Velocity.X = Speed;
                state = 2;
                direction = false;
                p_animation(0, 2);
            }
            else if (ks.IsKeyDown(Input.Left) && !AnimState && !AnimState2 && !MoveLock)
            {

                Velocity.X = -Speed;
                state = 3;
                direction = true;
                p_animation(0, 2);

            }
            else if (!AnimState && !AnimState2)
            {
                direction_check(0, 0, 1);
            }

            // Key Released Checks
            if (ks.IsKeyUp(Input.Up)) jumpkeydown = false;
            if (ks.IsKeyUp(Input.Down)) {Height = T_Height; Position = TPosition; poslock = false; }
            if (ks.IsKeyUp(Input.Attack)){attackkeydown = false;}
            if (ks.IsKeyUp(Input.Attack2)){attackkeydown2 = false;}

            if (InAir == true)
            {
                direction_check(6, 0, 3);
            }

            if (AnimState == true) {
                playonce = true;
                direction_check(0, 0 , 2);
            }
            else if (AnimState2 == true)
            {
                playonce = true;
                direction_check(2, 0, 2);
            }

            if (shurikenshow) {
                if (!SThrown)
                {
                    indirection = direction;
                    SThrown = true;
                }
                if (indirection)
                    SPosition.X -= 10;
                else
                    SPosition.X += 10;
            }

            
            // Local Functions
            void p_animation(int frames_start, int frames_end)
            {
                image3 = new Rectangle(0, 0, 20, 20); // Shuriken box
                time_elapsed += (float)gameTime.ElapsedGameTime.TotalMilliseconds;
                if (AnimState)
                {
                    image2 = new Rectangle((frames * T_Width2), (state * T_Height2), T_Width2, T_Height2); //Change the sprite location foreach frame
                }
                else if (AnimState2)
                {
                    image2 = new Rectangle((frames * T_Width2), (state * T_Height2), T_Width2, T_Height2); //Change the sprite location foreach frame
                }
                else
                {
                    image = new Rectangle((frames * T_Width), (state * T_Height), T_Width, T_Height); //Change the sprite location foreach frame
                }
                if (time_elapsed >= animation_length)
                {
                    
                    if (frames >= frames_end) {

                        if (playonce) {
                            AnimState = false;
                            AnimState2 = false;
                            playonce = false;
                        }
                        frames = frames_start;
                    }
                    else { frames++; }
                    time_elapsed = 0; //Reset to 0 
                }

            }

            void direction_check(int _state, int frames_start, int frames_end)
            {

                if (direction == false)
                {
                    state = _state;
                }
                else
                {
                    state = _state + 1;
                }
                p_animation(frames_start, frames_end);
            }


            

        }

        public override void CollisionCheck(GameTime gameTime, List<Sprite> sprites) {
            foreach (var sprite in sprites)
            {
                if (sprite == this)
                    continue;

                // To move
                if ((this.Velocity.X > 0 && this.IsTouchingLeft(sprite) && sprite.moveable) ||
                (this.Velocity.X < 0 && this.IsTouchingRight(sprite) && sprite.moveable))
                {
                    
                    this.Velocity.X = 0;

                    if (direction) {
                        sprite.Velocity.X -= 20;
                    }
                    else
                        sprite.Velocity.X += 20;
                }


                if ((this.Velocity.X > 0 && this.IsTouchingLeft(sprite)) ||
                    (this.Velocity.X < 0 && this.IsTouchingRight(sprite)))
                {
                    this.Velocity.X = 0;
                }
               


                if ((this.Velocity.Y > 0 && this.IsTouchingTop(sprite)) ||
                    (this.Velocity.Y < 0 && this.IsTouchingBottom(sprite)))
                {
                    this.Velocity.Y = 0;
                    InAir = false;
                    Grounded = true;
                }
                if (this.Velocity.Y > 0 && !(this.IsTouchingTop(sprite))) {
                    Grounded = false;
                }

                // Attack Collision
                if (AttackState)
                {
                    //Sword
                    if (this.IsOverlappedRight(sprite))
                    {
                        sprite.Health -= this.Damage;
                        sprite.Velocity.X += 10;
                    }
                    else if (this.IsOverlappedLeft(sprite)) {
                        sprite.Health -= this.Damage;
                        sprite.Velocity.X -= 10;
                    }
                    
                    atelapsed += (float)gameTime.ElapsedGameTime.TotalSeconds;

                    if (atelapsed > atduration)
                    {
                        AttackState = false;
                        atelapsed = 0;
                    }
                    
                }
                // Attack Collision
                if (shurikenshow)
                {
                    //Shuriken
                    if (this.IsOverlappedRight2(sprite))
                    {
                        sprite.Health -= this.Damage+10;
                        sprite.Velocity.X += 10;
                        shurikenshow = false;
                        SThrown = false;
                    }
                    else if (this.IsOverlappedLeft2(sprite))
                    {
                        sprite.Health -= this.Damage+10;
                        sprite.Velocity.X -= 10;
                        shurikenshow = false;
                        SThrown = false;
                    }
                    


                    
                }

            }

        }

     #endregion


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Ninja_Hunter.CustomLibrary;


namespace Ninja_Hunter.Sprites
{
    class EnemyPerson: Enemy
    {
        Rectangle image;
        int frames = 1;
        public new bool direction = false;
        float elapsed;
        float duration = 2f;
        public bool enemymove = true;
        public  new int Bounceback = 35;
        int css = 0;
        public EnemyPerson(Texture2D _texture) : base(_texture)
        {

        }

        public override void Update(GameTime gameTime, List<Sprite> sprites)
        {
            //Console.WriteLine("di " + direction);
            //Console.WriteLine(Health);
                if (direction) { frames = 0; } else { frames = 1; }
                image = new Rectangle((frames * (Width / 2)), 0, Width / 2, Height);

                // Main Checks
                Position.Y += Velocity.Y;
                Position.X += Velocity.X;
                Gravity(gameTime);
           
                if (collisionOn)
                {
                    CollisionCheck(gameTime, sprites);
                }
            
            if (enemymove)
            {
               
                if (Health <= 0) Died = true;


                // Enemy Loop from Right to Left
                if (MoveL && !MoveR && !MoveU && !MoveD)
                {
                    if (!HasMovedL)
                    {
                        NegativeDirection = true;
                        direction = true;
                        //Velocity.Y = -0.5f;
                        moveLeft(gameTime);
                    }

                    else if (HasMovedL)
                    {

                        NegativeDirection = false;
                        direction = false;

                        moveRight(gameTime);

                    }
                    if (HasMovedR)
                    {
                        HasMovedL = false;
                        HasMovedR = false;
                    }

                }
                elapsed += (float)gameTime.ElapsedGameTime.TotalSeconds;

                if (elapsed > duration)
                {
                    Velocity.Y = -15f;
                    elapsed = 0;
                }

            }
        }


        public override void Draw(SpriteBatch spriteBatch)
        {
            
            spriteBatch.Draw(texture, Position, image, Color.White);
        }

        public void Attack() {
            
            if (css < 10)
            {
                Velocity.X = -10;
                css++;
            }
            
        }



        public override void CollisionCheck(GameTime gameTime, List<Sprite> sprites)
        {
            foreach (var sprite in sprites)
            {
                if (sprite == this)
                    continue;



                if (this.IsTouchingLeft(sprite))
                {
                    Console.WriteLine("UUA: " + Velocity.X);
                    this.Velocity.X = 0;
                    sprite.Health -= 10;
                    sprite.Velocity.X += Bounceback;
                }
                else if (this.IsTouchingRight(sprite))
                {
                    this.Velocity.X = 0;
                    sprite.Health -= Damage;
                    sprite.Velocity.X -= Bounceback;
                }



                else if (this.IsTouchingTop(sprite))

                {
                    this.Velocity.Y = 0;
                    //sprite.Health -= Damage;
                    //sprite.Velocity.X -= Bounceback;
                }
                else if (this.IsTouchingBottom(sprite))
                {
                    this.Velocity.Y = 0;
                    //sprite.Health -= 10;
                    //sprite.Velocity.Y -= Bounceback;
                }



            }
        }
    }
}

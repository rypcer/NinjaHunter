﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Ninja_Hunter.Sprites
{

    class Enemy : Sprite
    {
        public enum AnimState
        {
            Left,
            Right,
            Down,
            Up,
            Attack
        }
        //GameTime _gameTime;
        public int DistanceL,DistanceR,DistanceU,DistanceD;
        public bool HasMovedL,HasMovedR, HasMovedU, HasMovedD = false;
        public bool MoveL, MoveR, MoveU, MoveD = false;
        public int Bounceback = 30;
        int distance_travelled;
        //new bool moveable = false;
       
        public bool NegativeDirection = false;
        public Enemy(Texture2D _texture) : base(_texture)
        {

        }

        public override void Update(GameTime gameTime, List<Sprite> sprites)
        {
            // Main Checks
            Position += Velocity;
            Gravity(gameTime);
            if (collisionOn)
            {
                CollisionCheck(gameTime, sprites);
            }
            if (destroyable)
            {
                if (Health <= 0) Died = true;
            }

            // Enemy Loop from Right to Left
            if (MoveL && !MoveR && !MoveU && !MoveD)
            {
                if (!HasMovedL)
                {
                    NegativeDirection = true;
                    moveLeft(gameTime);
                }

                else if (HasMovedL)
                {

                    NegativeDirection = false;
                    moveRight(gameTime);
                }
                if(HasMovedR){
                    HasMovedL = false;
                    HasMovedR = false;
                }
            }
            // Enemy Loop from Left to Right
            else if (MoveR && !MoveL && !MoveU && !MoveD)
            {
                if (!HasMovedR)
                {
                    NegativeDirection = false;
                    moveRight(gameTime);
                }

                else if (HasMovedR)
                {

                    NegativeDirection = true;
                    moveLeft(gameTime);
                }
                if (HasMovedL)
                {
                    HasMovedR = false;
                    HasMovedL = false;
                }
            }
            // Enemy Loop from Bottom to Top
            if (!MoveL && !MoveR && MoveU && !MoveD)
            {
                if (!HasMovedU)
                {
                    NegativeDirection = true;
                    moveUp(gameTime);
                }

                else if (HasMovedU)
                {

                    NegativeDirection = false;
                    moveDown(gameTime);
                }
                if (HasMovedD)
                {
                    HasMovedU = false;
                    HasMovedD = false;
                }
            }
            // Enemy Loop from Top to Bottom
            if (!MoveL && !MoveR && !MoveU && MoveD)
            {
                if (!HasMovedD)
                {
                    NegativeDirection = false;
                    moveDown(gameTime);
                }

                else if (HasMovedD)
                {

                    NegativeDirection = true;
                    moveUp(gameTime);
                }
                if (HasMovedU)
                {
                    HasMovedD = false;
                    HasMovedU = false;
                }
            }



        }

        public void moveLeft(GameTime gameTime) {
           
            move(gameTime,DistanceL,ref HasMovedL,ref Velocity.X);
            
        }
        public void moveRight(GameTime gameTime)
        {
            
            move(gameTime, DistanceR, ref HasMovedR, ref Velocity.X);

        }
        public void moveUp(GameTime gameTime)
        {

            move(gameTime, DistanceU, ref HasMovedU, ref Velocity.Y);
        }
        public void moveDown(GameTime gameTime)
        {

            move(gameTime, DistanceD, ref HasMovedD, ref Velocity.Y);
        }


        public void move(GameTime gameTime,int Distance, ref bool HasMoved,ref float Velocity)
        {
            
               
                if (distance_travelled < Distance && !HasMoved)
                {

                    if (NegativeDirection)
                        Velocity -= Speed * (float)gameTime.ElapsedGameTime.TotalSeconds;
                    else
                        Velocity += Speed * (float)gameTime.ElapsedGameTime.TotalSeconds;
                    distance_travelled++;

                }
                else
                {

                    distance_travelled = 0;
                    Velocity = 0;
                    HasMoved = true;

                }
            
            
        }

        public override void CollisionCheck(GameTime gameTime, List<Sprite> sprites)
        {
            foreach (var sprite in sprites)
            {
                if (sprite == this)
                    continue;



                if (this.IsTouchingLeft(sprite))
                {
                    this.Velocity.X = 0;
                    sprite.Health -= 10;
                    sprite.Velocity.X += Bounceback;
                }
                else if (this.IsTouchingRight(sprite)) {
                    this.Velocity.X = 0;
                    sprite.Health -= Damage;
                    sprite.Velocity.X -= Bounceback;
                }



                else if (this.IsTouchingTop(sprite))

                {
                    this.Velocity.Y = 0;
                    sprite.Health -= Damage;
                    sprite.Velocity.X -= Bounceback;
                }
                else if (this.IsTouchingBottom(sprite))
                {
                    this.Velocity.Y = 0;
                    sprite.Health -= 10;
                    sprite.Velocity.Y -= Bounceback;
                }



            }
        }




    }
}

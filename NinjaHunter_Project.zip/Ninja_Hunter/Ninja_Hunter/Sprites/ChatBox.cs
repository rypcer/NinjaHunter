﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Ninja_Hunter.CustomLibrary;
namespace Ninja_Hunter.Sprites
{
    public class ChatBox
    {
        Texture2D chatboxtexture;
        Rectangle image;
        public bool chatboxshow = false; // Allow DilaogueS
        public bool dialogue_enabled = false;
        Player p;
        EnemyPerson jay;
        SpriteFont chatfont;
        String chatText;
        //bool chatlock;
        bool attackanim = false;
        bool onetime = false;
        String chatletters = "";
        List<String> Dialogues;
        List<int> DialoguePos;
        int i = 1;
        bool init;
        int person =0;
        int chatcount = 0;  // Shows which chat messages appear default 0
        int count = 0; // Used to as an index for accessing dialogue list
        int state = 0;
        bool moveallow = false;
        bool textwrite = true;
        float elapsedTime = 0f;
        
        int tempdistance;
        float time_elapsed = 0;
        bool Dialogue2 = false;
        bool Dialogue3 = false;
        bool Dialogue4 = false;
        int Dialogue2pos;
        int Dialogue3pos;
        int Dialogue4pos;
        bool Dialogue1_f, Dialogue2_f, Dialogue3_f ,Dialogue4_f= false;
        
        Vector2 posbox = new Vector2(410, 30);
        Vector2 postext = new Vector2(505, 70);
        Camera cam;
        KeyboardState laststate = new KeyboardState();
        KeyboardState currentstate = new KeyboardState();


        public enum AnimState {
            Left,
            Right,
            Jump,
            Attack
        }

        public ChatBox(Texture2D _chatboxtexture, SpriteFont _chatfont)
        {
            chatboxtexture = _chatboxtexture;
            chatfont = _chatfont;
            DialoguePos = new List<int> {100, 2000,3421,4020};
            Dialogue2pos = DialoguePos[1];
            Dialogue3pos = DialoguePos[2];
            Dialogue4pos = DialoguePos[3];
            Dialogues = new List<String> {
                "  My Boi I have trained you very well,\nIt is now time that you bring the Shadow -\nScroll back to my possesion.",
                "My stupid deciple has stolen the scroll\na long time ago. Go finish him off\nand I will reward you!",
                "Boi you can jump with  W\nWalk left with A  or Right with D\nAttack with Space and Throw with LShift",
                "Ok now go find Durum Dara and don't come\nback unless you have scroll.\nAlso, don't use Gate. UNDERSTAND!",
                " ok master...",

                " Master What happened why you Gate locked?",
                " Because you no good to me, go bring me\nscroll then we see...",
                " Noo master, pls let me in?!",
                " Im said NO now get tha heck away from\nme I teach you everything I knew!",
                " Master pls let me in you didn't teach\nme nothing! I'm still weak like potatoe \nDurum Dare will kill me...",
                " You get uncertain as master is not responding \nto you...\nWill this be the end?",

                "  Da hell?!",
                " How you come inside my buidling?",
                " I thought it is being guarded and secured with\nmy new traps...",
                " What you talking about?, I seen No guards bruh\n",
                " Only thing I seen was malfunctiong traps ",
                " Ahhhhhhhrghhhque huh...",
                " Ey yo what the pak?! Why you hit me bruv?\n you crazy or what?",
                " You no calling me bruv YOu uNderstand?\nI will showing you otheriwse my skill!",
               
                "  Yooo who this guy?!",
                "  Dont know bruv... He thinks he can beat us hha",
                "  Huhhuehheaaha, get this tuk tuk scam\noutma sight slave! Erhm I mean bruv.",
                "  Ok boss!\n You listen huHA!? Im going beat you up\n LESS GOOO!",

                " Oh sh*t pls don't kill me bruv, \nimma giving you alll ma chochlate mon...\nI mean real money to you!",
                " Ok, tell me where Durum Dara is otherwise \nYOU DeaD!",
                "  Hmm...\n I dunno know bruv",
                " Wrong ANWSER you DEAD!\nIm gonna steal your 'Ma G' \nalbum label cover aswell!",
                " No Way im gonna die in this sh*t hole bruv...\nImma outta here...\nTake that fake label it was Lil Jay's crap label",


                "  Once you have defeated Lil Jay you notice \nthat the turd smell dissapeared,\n Your Nostrils feel relieved!",
                "  You receive an incoming \" telepathic \" call,\n from your master's 5 pound nokia phone!",

                "  Hello Master? Why you doing?\n I defeated some Lil Jay \nor what his name was...",
                " But I lost one guy his name was \nLil G Marco Polo! So I'm take his Album Label",

                "  You did what?! PaK your 'why you doing' question\nWho said you can kill JAY JAY XIANG WUNG!?",

                "  Yes Master are you prouding of me?",

                "  NO YOU STUPID?! He was my long lost SON!\n Marco Polo this bastard abduct\n him but I could never find him!",
                "  Im going to punish you! YOu not My student\nanymore cause you killing my Son h\nDDEEAD NOW WHAT CAN I DO NOW HUH!?",
                "  PACH YOUR ALbum its uselessing for me Now!",

                " Oh no im sorry I will bring him back oneday!",

                " NO YOU STUOID CRAZ yy.....",

                " You hang Up & put your phone on flight mode\n so he doesnt call you again!"
            };
        }

        public void Update(List<Sprite> _sprites, GameTime gameTime, Camera _cam, List<Sprite> _animations)
        {
            //Extract PLayer from Sprites and assign to this class temp Player
            if (_sprites[0] is Player)
            {
                p = _sprites[0] as Player;
            }
            
            if (dialogue_enabled)
            {
                cam = _cam;
                image = new Rectangle(0, person * (chatboxtexture.Height / 5), chatboxtexture.Width, chatboxtexture.Height / 5);
                laststate = currentstate;
                currentstate = Keyboard.GetState();

                

                //Extract Lil Jay from Sprites and assign to this class temp Player
                if (_sprites[2] is EnemyPerson)
                {
                    jay = _sprites[2] as EnemyPerson;
                }

                // All Dialouge Players
                if (p.Position.X >= DialoguePos[0] && p.Position.X <= DialoguePos[0] + 30)
                {
                    //Dialogue 1
                    if (ChatState(0))
                    {
                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 0, 4);

                    }
                    else if (ChatState(1))
                    {
                        person = 1;
                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 4, 5);
                    }
                    else if (ChatState(2))
                    {
                        Dialogue1_f = true;
                    }
                }
                //Dialogue 2
                else if (Dialogue2)
                {
                    if (ChatState(2))
                    {

                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 5, 6);
                    }
                    else if (ChatState(3))
                    {
                        person = 0;
                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 6, 7);
                    }
                    else if (ChatState(4))
                    {
                        person = 1;
                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 7, 8);
                    }
                    else if (ChatState(5))
                    {
                        person = 0;
                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 8, 9);
                    }
                    else if (ChatState(6))
                    {
                        person = 1;
                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 9, 10);
                    }
                    else if (ChatState(7))
                    {
                        person = 3;
                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 10, 11);
                    }
                    else if (ChatState(8))
                    {
                        Dialogue1_f = false;
                        Dialogue2_f = true;
                        Dialogue2 = false;
                    }
                }
                //Dialogue 3
                else if (Dialogue3)
                {
                    if (ChatState(8))
                    {
                        person = 2;
                        jay.enemymove = false;
                        jay.Velocity.X = 0;
                        jay.direction = true;

                        Console.WriteLine("asdasd: " + jay.Velocity.X);
                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 11, 14);
                    }
                    else if (ChatState(9))
                    {
                        person = 1;


                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 14, 16);
                    }
                    else if (ChatState(10))
                    {
                        person = 2;
                        jay.Attack();

                        Console.WriteLine("XX: " + jay.Velocity.X);

                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 16, 17);
                    }
                    else if (ChatState(11))
                    {
                        jay.Velocity.X = 0;
                        person = 1;
                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 17, 18);
                    }
                    else if (ChatState(12))
                    {
                        person = 2;
                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 18, 19);
                    }
                    else if (ChatState(13))
                    {
                        person = 4;
                        cam.movecam(60, 10, true); //Move cam to right

                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 19, 20);
                    }
                    else if (ChatState(14))
                    {
                        person = 2;


                        cam.movecam(40, 10, false); //Move cam to left

                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 20, 21);
                    }
                    else if (ChatState(15))
                    {
                        person = 4;
                        cam.movecam(40, 10, true); //Move cam to left

                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 21, 22);
                    }
                    else if (ChatState(16))
                    {
                        person = 2;
                        cam.movecam(60, 10, false); //Move cam to left

                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 22, 23);
                        cam.cam_unlock = false;
                        jay.enemymove = true;
                    }
                    else if (ChatState(17))
                    {
                        Dialogue2_f = false;
                        Dialogue3_f = true;
                        Dialogue3 = false;
                    }

                }
                //Dilaogue 4
                else if (Dialogue4)
                {

                    if (ChatState(17) && jay.Died)
                    {
                        person = 4;

                        cam.movecam(1, 10, true);
                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 23, 24);


                    }
                    else if (ChatState(18))
                    {
                        person = 1;

                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 24, 25);


                    }
                    else if (ChatState(19))
                    {
                        person = 4;

                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 25, 26);


                    }
                    else if (ChatState(20))
                    {
                        person = 1;

                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 26, 27);


                    }
                    else if (ChatState(21))
                    {
                        person = 4;
                        _animations[1].Position.X += 7f;

                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 27, 28);


                    }
                    else if (ChatState(22))
                    {
                        person = 3;

                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 28, 30);


                    }
                    else if (ChatState(23))
                    {
                        person = 1;

                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 30, 32);


                    }
                    else if (ChatState(24))
                    {
                        person = 0;

                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 32, 33);


                    }
                    else if (ChatState(25))
                    {
                        person = 1;

                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 33, 34);


                    }
                    else if (ChatState(26))
                    {
                        person = 0;
                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 34, 37);

                    }
                    else if (ChatState(27))
                    {
                        person = 1;
                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 37, 38);

                    }
                    else if (ChatState(28))
                    {
                        person = 0;
                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 38, 39);

                    }
                    else if (ChatState(29))
                    {
                        person = 3;
                        if (init) { chatinit(); }
                        DialoguePlayer(gameTime, 39, 40);

                    }
                    else if (ChatState(30))
                    {
                        Dialogue3_f = false;
                        Dialogue4_f = true;
                        Dialogue4 = false;
                    }
                }


                //Dialogue Walk animation

                if (Dialogue1_f)
                {
                    moveplayer(gameTime, ref Dialogue2pos, 80, AnimState.Left, ref Dialogue2);
                }
                else if (Dialogue2_f)
                {
                    moveplayer(gameTime, ref Dialogue3pos, 30, AnimState.Right, ref Dialogue3);
                }
                else if (Dialogue3_f)
                {
                    moveplayer(gameTime, ref Dialogue4pos, 30, AnimState.Right, ref Dialogue4);
                }
            }


        }


        public void moveplayer(GameTime gameTime, ref int position, int distance, AnimState state,ref bool Dialoguestate) {

            if (p.Position.X >= position && p.Position.X <= position+50)
            {
                p.MoveLock = true;
                moveallow = true;
            }
            if (moveallow && state== AnimState.Left)
            {
                moveleft(gameTime, distance,ref Dialoguestate, ref position);

            }
            else if(moveallow && state == AnimState.Right)
            {
                moveright(gameTime, distance, ref Dialoguestate, ref position);

            }


        }
        void moveleft(GameTime gameTime, int distance, ref bool Dialoguestate, ref int Dposition)
        {
            state = 3;
            p.direction = true;
            if (tempdistance < distance)
            {
                //Console.WriteLine(p.Velocity.X);
                p_animation(gameTime, 0, 2);
                p.Velocity.X = -4;
                tempdistance++;
            }
            else { moveallow = false; tempdistance = 0; p.MoveLock = false; Dialoguestate = true; Dposition = -100;  } //Dposition Set triggerposition way back so it doesnt trigger dialogue again
        }
        void moveright(GameTime gameTime, int distance, ref bool Dialoguestate, ref int Dposition)
        {
            state = 2;
            p.direction = false;
            if (tempdistance < distance)
            {
                //Console.WriteLine(p.Velocity.X);
                p_animation(gameTime, 0, 2);
                p.Velocity.X = +4;
                tempdistance++;
            }
            else { moveallow = false; tempdistance = 0; p.MoveLock = false; Dialoguestate = true; Dposition = -100; } 
        }
        // animations
        void p_animation(GameTime gameTime,int frames_start, int frames_end)
        {
            
            time_elapsed += (float)gameTime.ElapsedGameTime.TotalMilliseconds;
            if (attackanim)
            {
                p.image2 = new Rectangle((p.frames * p.T_Width2), (state * p.T_Height2), p.T_Width2, p.T_Height2); //Change the sprite location foreach frame
            }

            else
            {
                p.image = new Rectangle((p.frames * p.T_Width), (state * p.T_Height), p.T_Width, p.T_Height);
            }
            if (time_elapsed >= 3000f)
            {

                if (p.frames >= frames_end)
                {

                    if (p.playonce)
                    {
                        attackanim = false;
                        p.playonce = false;
                    }
                    p.frames = frames_start;
                }
                else { p.frames++; }
                time_elapsed = 0; //Reset to 0 
            }

        }


        public bool ChatState(int count) {
            return chatcount == count;
        }
        
        public bool IsNewKeyPress(params Keys[] keys)   // Used so Space can only be pressed once
        {
            return keys.Any(k => (currentstate.IsKeyDown(k) &&
                        laststate.IsKeyUp(k)));
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            if (chatboxshow)
            {
               
                spriteBatch.Draw(chatboxtexture, posbox,image, Color.White);
                spriteBatch.DrawString(chatfont, chatletters, postext, Color.White);
                
            }

        }

        void chatinit() {
            chatText = "";
            i = 1;
            count = 0;
            chatboxshow = true;
            textwrite = true;
            init = false;
            cam.reached = false;
        }

        public void DialoguePlayer(GameTime gameTime, int Dstart, int Dend)
        {

            if (!onetime) {
                count = Dstart;
                
                onetime = true;
               
            }



            // If chat displayed  Player cannot move
            if (chatboxshow)
            {
                p.MoveLock = true;

            }

            //Display Next dialogue
            chatText = Dialogues[count];
           
            if (textwrite)
            {


                elapsedTime += (float)gameTime.ElapsedGameTime.TotalMilliseconds;
                if (elapsedTime >= 16)
                {
                    chatletters += Convert.ToString(chatText[i]);

                    elapsedTime = 0;
                }

                //Console.WriteLine(i + " " + chatText.Length);
                if (i >= chatText.Length - 1) { textwrite = false; i = 0; }
                else { i++; }
            }

            if (IsNewKeyPress(Keys.Tab))
            {

                if (count < Dend - 1)
                {

                    i = 0;
                    count++;
                    Console.WriteLine(count);
                    textwrite = true;
                    chatletters = "";
                }

                else
                {
                   
                    count = 0;
                    i = 0;
                    chatboxshow = false;
                    p.MoveLock = false;
                    onetime = false;
                    chatletters = "";
                    init = true;
                    chatcount += 1;
                    
                }


            }

        }
    }
}

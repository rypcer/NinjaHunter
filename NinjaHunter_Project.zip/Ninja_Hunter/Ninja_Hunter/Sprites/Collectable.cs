﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Ninja_Hunter.Sprites
{
    class Collectable: Sprite
    {
        public Collectable(Texture2D _texture):base(_texture)
        {
            texture = _texture;

        }

        public override void Update(GameTime gameTime, List<Sprite> sprites)
        {
            
            CollisionCheck(gameTime,sprites);

            
        }

        public override void CollisionCheck(GameTime gameTime, List<Sprite> sprites)
        {
            foreach (var sprite in sprites)
            {
                if (sprite == this)
                    continue;



                if ((this.IsTouchingLeft(sprite)) ||
                    (this.IsTouchingRight(sprite)))
                {

                    Died = true;
                }



                if ((this.IsTouchingTop(sprite)) ||
                    (this.IsTouchingBottom(sprite)))
                {
                    Died = true;
                }

            }

        }
    }
}

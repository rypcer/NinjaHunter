﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Ninja_Hunter.Sprites;

namespace Ninja_Hunter.CustomLibrary
{
    public class Camera
    {
        bool init = false;
        float posY;
        public float posX = 1;
        public Matrix Transform { get; private set; }
        public bool cam_unlock = false;
        public int travelled;
        public bool reached = false;
        Sprite target;
        public void movecam(int distance,int speed,bool direction)
        {
            
            if (travelled < distance && !reached)
            {
                cam_unlock = true;
                if (direction)
                    posX -= speed;
                else
                {
                    posX += speed;
                    Console.Write("posX: " + posX);
                }
                travelled++;
            }
            else  {
                travelled = 0;
                reached = true;
            }
            


        }
        public void Follow(Sprite _target) {
            target = _target;
            //Console.WriteLine(posX);
            if (!cam_unlock) {
            
                if (!init) {
                    posY = -target.Position.Y - (target.HitBox.Height / 2 + 36);
                    init = true;
                }
                if (-target.Position.X >= -250)
                {
                    posX = -250;

                }
                else if (-target.Position.X <= -4151) {
                    posX = -4151;     //563
                }
                else
                {
                    posX = -target.Position.X;
                }
            }
            var position = Matrix.CreateTranslation(
                posX,
                posY,
                0);

            var offset = Matrix.CreateTranslation(
                Game1.ScreenWidth / 2,
                Game1.ScreenHeight / 2, 
                0);

            Transform = position * offset;
        }
    }
}
